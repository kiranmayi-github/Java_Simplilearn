package com.ecommerce.dao;

import java.util.List;

import org.hibernate.SessionFactory;


public class EProductDAO {

        
    private SessionFactory sessionFactory;

        @SuppressWarnings("unchecked")
        public List<EProductDAO> getAllProducts() {
                return this.sessionFactory.getCurrentSession().createQuery("from EProducts").list();
        }
}

