package com.ecommerce.Controller;

public @interface Autowired {

}
